/**
 * array_stats_test.h for Assignment 2, CMPT 300 Summer 2020
 * Name: Devansh Chopra
 * Student #: 301-275-491
 */

#ifndef _ARRAY_STATS_S_H
#define _ARRAY_STATS_S_H

struct array_stats_s{
   long min;
   long max;
   long sum; 
};

#endif
